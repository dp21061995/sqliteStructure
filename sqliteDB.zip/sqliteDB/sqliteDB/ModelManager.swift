//
//  ModelManager.swift
//  sqliteDB
//
//  Created by vishal on 8/23/18.
//  Copyright © 2018 Echo. All rights reserved.
//

import UIKit


class ModelManager: NSObject {

    static let sharedInstance = ModelManager()
    
    override init(){
        
        super.init()
    }
   
    /*func getInstance() -> ModelManager {
        if(ModelManager.sharedInstance.database == nil)
        {
            sharedInstance.database = FMDatabase(path: Util.getPath("studInfoDB.sqlite"))
        }
        return sharedInstance
    }
 */
    
}
